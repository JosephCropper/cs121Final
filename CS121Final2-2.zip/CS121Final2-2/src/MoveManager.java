import java.util.ArrayList;
import java.util.Random;

public class MoveManager {
    private ArrayList<Move> moveList = new ArrayList<>();
    private boolean lightScreen = false;
    private boolean reflect = false;
    private int weather = 0;
    //0 = clear, 1 = Rain, 2 = Sun, 3 = Sand


    public MoveManager(){
        moveList.add(new Move("Calm_Mind", "psychic", 0, 100, 0, false, false, false));

    }

    public int moveOrder(String moveOneName, String moveTwoName){
        //0 = same bracket, 1 = move one moves first, -1 move two moves first
        int moveOnePriority = 0, moveTwoPriority = 0;
        for (int i = 0; i < moveList.size(); i++){
            if (moveOneName.compareToIgnoreCase(moveList.get(i).getName()) == 0){
                moveOnePriority = moveList.get(i).getPriority();
            }
            if (moveTwoName.compareToIgnoreCase(moveList.get(i).getName()) == 0){
                moveTwoPriority = moveList.get(i).getPriority();
            }
        }
        if (moveOnePriority > moveTwoPriority){
            return 1;
        }
        else if (moveTwoPriority > moveOnePriority){
            return -1;
        }
        return 0;
    }

    public void useMove(Pokemon attackingMon, Pokemon defendingMon, String moveName){
        Move move;
        for (int i = 0; i < moveList.size(); i++){
            if (moveName.compareTo(moveList.get(i).getName()) == 0){
                move = moveList.get(i);
                System.out.println(attackingMon.getName() + " used " + move.getName());
                //Standard checks
                int damage  = (int)(calcDamage(attackingMon, defendingMon, move));
                defendingMon.setGameStats(0, defendingMon.getGameStats(0) - damage);
                if (move.getContact()){
                    contactCheck(attackingMon, defendingMon);
                }
                if (move.getRecoil()){
                    attackingMon.setGameStats(0, attackingMon.getGameStats(0) - (damage/3));
                    if (attackingMon.getGameStats(0) <= 0) {
                        attackingMon.setGameStats(0, 0);
                        System.out.println(attackingMon.getName() + " fainted!");
                    }
                }
                if (defendingMon.getGameStats(0) <= 0) {
                    defendingMon.setGameStats(0, 0);
                    System.out.println(defendingMon.getName() + " fainted!");
                }


                secondaryEffect(attackingMon, defendingMon, move);
            }
        }
    }

    public void secondaryEffect(Pokemon attackingMon, Pokemon defendingMon, Move move){
        int bonus = 1;
        if (attackingMon.getAbility().compareToIgnoreCase("Serene_Grace") == 0){
            bonus++;
        }
        switch (move.getName().toLowerCase()){
            case "calm_mind":
                attackingMon.setGameStats(3, (int)(attackingMon.getGameStats(3)*1.5));
                attackingMon.setGameStats(4, (int)(attackingMon.getGameStats(4)*1.5));
                break;

        }
    }

    public void contactCheck(Pokemon attackingMon, Pokemon defendingMon){
        switch(defendingMon.getAbility().toLowerCase()) {
            case "rough_skin":
                System.out.println(attackingMon.getName() + " was hurt by " + defendingMon.getName() + "\'s " + defendingMon.getAbility());
                attackingMon.setGameStats(0, attackingMon.getGameStats(0) - (attackingMon.getMaxStats(0) / 8));
                if (attackingMon.getGameStats(0) <= 0) {
                    attackingMon.setGameStats(0, 0);
                    System.out.println(attackingMon.getName() + " fainted!");
                }
                break;
        }
    }

    public double calcDamage(Pokemon atkMon, Pokemon defMon, Move move){
        String[] attackingMon = atkMon.getTypes();
        String[] defendingMon = defMon.getTypes();
        String moveType = move.getType();
        double type = 1;
        switch (moveType.toLowerCase()){
            case "normal":
                if (defendingMon[0].compareToIgnoreCase("rock") == 0 || defendingMon[1].compareToIgnoreCase("rock") == 0){
                    type*=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 || defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type*=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("ghost") == 0 || defendingMon[1].compareToIgnoreCase("ghost") == 0){
                    type = 0;
                }
                break;
            case "fighting":
                if (defendingMon[0].compareToIgnoreCase("normal") == 0 || defendingMon[1].compareToIgnoreCase("normal") == 0){
                    type*=2;
                }
                if (defendingMon[0].compareToIgnoreCase("rock") == 0 || defendingMon[1].compareToIgnoreCase("rock") == 0){
                    type*=2;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("ice") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ice") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("dark") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dark") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("flying") == 0 ||
                        defendingMon[1].compareToIgnoreCase("flying") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("poison") == 0 ||
                        defendingMon[1].compareToIgnoreCase("poison") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("bug") == 0 ||
                        defendingMon[1].compareToIgnoreCase("bug") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("psychic") == 0 ||
                        defendingMon[1].compareToIgnoreCase("psychic") == 0){
                    type*=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("fairy") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fairy") == 0){
                    type*= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("ghost") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ghost") == 0){
                    type = 0;
                }
                break;
            case "flying":
                if (defendingMon[0].compareToIgnoreCase("fighting") == 0 || defendingMon[1].compareToIgnoreCase("fighting") == 0){
                    type *=2;
                }
                if (defendingMon[0].compareToIgnoreCase("bug") == 0 ||
                        defendingMon[1].compareToIgnoreCase("bug") == 0){
                    type*=2;
                }
                if (defendingMon[0].compareToIgnoreCase("grass") == 0 ||
                        defendingMon[1].compareToIgnoreCase("grass") == 0){
                    type *=2;
                }

                if (defendingMon[0].compareToIgnoreCase("rock") == 0 ||
                        defendingMon[1].compareToIgnoreCase("rock") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("electric") == 0 ||
                        defendingMon[1].compareToIgnoreCase("electric") == 0){
                    type *= .5;
                }
                break;
            case "poison":
                if (defendingMon[0].compareToIgnoreCase("grass") == 0 || defendingMon[1].compareToIgnoreCase("grass") == 0){
                    type *=2;
                }
                if (defendingMon[0].compareToIgnoreCase("fairy") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fairy") == 0){
                    type *=2;
                }

                if (defendingMon[0].compareToIgnoreCase("poison") == 0 ||
                        defendingMon[1].compareToIgnoreCase("poison") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("ground") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ground") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("rock") == 0 ||
                        defendingMon[1].compareToIgnoreCase("rock") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("ghost") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ghost") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type = 0;
                }
                break;
            case "ground":
                if (defendingMon[0].compareToIgnoreCase("poison") == 0 || defendingMon[1].compareToIgnoreCase("poison") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("rock") == 0 ||
                        defendingMon[1].compareToIgnoreCase("rock") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *=2;
                }
                if (defendingMon[0].compareToIgnoreCase("fire") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fire") == 0){
                    type *=2;
                }
                if (defendingMon[0].compareToIgnoreCase("electric") == 0 ||
                        defendingMon[1].compareToIgnoreCase("electric") == 0){
                    type *=2;
                }

                if (defendingMon[0].compareToIgnoreCase("bug") == 0 ||
                        defendingMon[1].compareToIgnoreCase("bug") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("grass") == 0 ||
                        defendingMon[1].compareToIgnoreCase("grass") == 0){
                    type*=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("flying") == 0 ||
                        defendingMon[1].compareToIgnoreCase("flying") == 0){
                    type = 0;
                }
                break;
            case "rock":
                if (defendingMon[0].compareToIgnoreCase("flying") == 0 || defendingMon[1].compareToIgnoreCase("flying") == 0){
                    type*=2;
                }
                if (defendingMon[0].compareToIgnoreCase("bug") == 0 ||
                        defendingMon[1].compareToIgnoreCase("bug") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("fire") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fire") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("ice") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ice") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("fighting") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fighting") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("ground") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ground") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= .5;
                }
                break;
            case "bug":
                if (defendingMon[0].compareToIgnoreCase("grass") == 0 ||
                        defendingMon[1].compareToIgnoreCase("grass") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("psychic") == 0 ||
                        defendingMon[1].compareToIgnoreCase("psychic") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("dark") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dark") == 0){
                    type *=2;
                }

                if (defendingMon[0].compareToIgnoreCase("fighting") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fighting") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("flying") == 0 ||
                        defendingMon[1].compareToIgnoreCase("flying") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("poison") == 0 ||
                        defendingMon[1].compareToIgnoreCase("poison") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("ghost") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ghost") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("fire") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fire") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("fairy") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fairy") == 0){
                    type *= .5;
                }
                break;
            case "ghost":
                if (defendingMon[0].compareToIgnoreCase("ghost") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ghost") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("psychic") == 0 ||
                        defendingMon[1].compareToIgnoreCase("psychic") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("dark") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dark") == 0){
                    type *=.5;
                }
                if (defendingMon[0].compareToIgnoreCase("normal") == 0 ||
                        defendingMon[1].compareToIgnoreCase("normal") == 0){
                    type = 0;
                }
                break;
            case "steel":
                if (defendingMon[0].compareToIgnoreCase("rock") == 0 ||
                        defendingMon[1].compareToIgnoreCase("rock") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("ice") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ice") == 0){
                    type *=2;
                }
                if (defendingMon[0].compareToIgnoreCase("fairy") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fairy") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("fire") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fire") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("water") == 0 ||
                        defendingMon[1].compareToIgnoreCase("water") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("electric") == 0 ||
                        defendingMon[1].compareToIgnoreCase("electric") == 0){
                    type *= .5;
                }
                break;
            case "fire":
                if (weather == 2){
                    type *= 1.5;
                }
                else if (weather == 1){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("bug") == 0 ||
                        defendingMon[1].compareToIgnoreCase("bug") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("grass") == 0 ||
                        defendingMon[1].compareToIgnoreCase("grass") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("ice") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ice") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("rock") == 0 ||
                        defendingMon[1].compareToIgnoreCase("rock") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("fire") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fire") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("water") == 0 ||
                        defendingMon[1].compareToIgnoreCase("water") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("dragon") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dragon") == 0){
                    type *= .5;
                }
                break;
            case "water":
                if (weather == 1){
                    type *= 1.5;
                }
                else if (weather == 2){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("ground") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ground") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("rock") == 0 ||
                        defendingMon[1].compareToIgnoreCase("rock") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("fire") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fire") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("water") == 0 ||
                        defendingMon[1].compareToIgnoreCase("water") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("grass") == 0 ||
                        defendingMon[1].compareToIgnoreCase("grass") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("dragon") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dragon") == 0){
                    type *= .5;
                }
                break;
            case "grass":
                if (defendingMon[0].compareToIgnoreCase("ground") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ground") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("rock") == 0 ||
                        defendingMon[1].compareToIgnoreCase("rock") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("water") == 0 ||
                        defendingMon[1].compareToIgnoreCase("water") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("flying") == 0 ||
                        defendingMon[1].compareToIgnoreCase("flying") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("poison") == 0 ||
                        defendingMon[1].compareToIgnoreCase("poison") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("bug") == 0 ||
                        defendingMon[1].compareToIgnoreCase("bug") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("fire") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fire") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("grass") == 0 ||
                        defendingMon[1].compareToIgnoreCase("grass") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("dragon") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dragon") == 0){
                    type *= .5;
                }
                break;
            case "electric":
                if (defendingMon[0].compareToIgnoreCase("flying") == 0 ||
                        defendingMon[1].compareToIgnoreCase("flying") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("water") == 0 ||
                        defendingMon[1].compareToIgnoreCase("water") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("grass") == 0 ||
                        defendingMon[1].compareToIgnoreCase("grass") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("electric") == 0 ||
                        defendingMon[1].compareToIgnoreCase("electric") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("dragon") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dragon") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("ground") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ground") == 0){
                    type = 0;
                }
                break;
            case "psychic":
                if (defendingMon[0].compareToIgnoreCase("fighting") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fighing") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("poison") == 0 ||
                        defendingMon[1].compareToIgnoreCase("poison") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("psychic") == 0 ||
                        defendingMon[1].compareToIgnoreCase("psychic") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("dark") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dark") == 0){
                    type = 0;
                }
                break;
            case "ice":
                if (defendingMon[0].compareToIgnoreCase("flying") == 0 ||
                        defendingMon[1].compareToIgnoreCase("flying") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("ground") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ground") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("grass") == 0 ||
                        defendingMon[1].compareToIgnoreCase("grass") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("dragon") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dragon") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("fire") == 0 ||
                    defendingMon[1].compareToIgnoreCase("fire") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("water") == 0 ||
                        defendingMon[1].compareToIgnoreCase("water") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("ice") == 0 ||
                        defendingMon[1].compareToIgnoreCase("ice") == 0){
                    type *= .5;
                }
                break;
            case "dragon":
                if (defendingMon[0].compareToIgnoreCase("dragon") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dragon") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("fairy") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fairy") == 0){

                    type = 0;
                }

                break;
            case "dark":
                if (defendingMon[0].compareToIgnoreCase("ghost") == 0 || defendingMon[1].compareToIgnoreCase("ghost") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("psychic") == 0 ||
                        defendingMon[1].compareToIgnoreCase("psychic") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("fighting") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fighting") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("dark") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dark") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("fairy") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fairy") == 0){
                    type *= .5;
                }
                break;
            case "fairy":
                if (defendingMon[0].compareToIgnoreCase("fighting") == 0 || defendingMon[1].compareToIgnoreCase("fighting") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("dragon") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dragon") == 0){
                    type *= 2;
                }
                if (defendingMon[0].compareToIgnoreCase("dark") == 0 ||
                        defendingMon[1].compareToIgnoreCase("dark") == 0){
                    type *= 2;
                }

                if (defendingMon[0].compareToIgnoreCase("poison") == 0 ||
                        defendingMon[1].compareToIgnoreCase("poison") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("steel") == 0 ||
                        defendingMon[1].compareToIgnoreCase("steel") == 0){
                    type *= .5;
                }
                if (defendingMon[0].compareToIgnoreCase("fire") == 0 ||
                        defendingMon[1].compareToIgnoreCase("fire") == 0){
                    type *= .5;
                }
                break;
        }



        if (moveType.compareTo(attackingMon[0]) == 0 || moveType.compareTo(attackingMon[1]) == 0){
            type *= 1.5;
        }
        Random rand = new Random();
        boolean crit = false;
        switch (atkMon.getCritTier()){
            case 1:
                if (rand.nextInt(1, 25) == 1){
                    crit = true;
                }
                break;
            case 2:
                if (rand.nextInt(1, 9) == 1){
                    crit = true;
                }
                break;
            case 3:
                if (rand.nextInt(1, 3) == 1){
                    crit = true;
                }
                break;
            default:
                crit = true;
                break;
        }
        if (crit){
            type *= 1.5;
        }
        type *= (rand.nextInt(85, 101) / 100.0);
        if (move.getPhysical() && atkMon.getStatus() == 1){
            type *= .5;
        }
        if ((move.getPhysical() && reflect) || (!move.getPhysical()) && lightScreen){
            type *= .5;
        }

        if (move.getPhysical()){
            type = type * ((42 * move.getDamage() * ((atkMon.getGameStats(1) * 1.0) / defMon.getGameStats(2) ) ) / 50.0);
        }
        else{
            type = type * ((42 * move.getDamage() * ((atkMon.getGameStats(3) * 1.0) / defMon.getGameStats(4) ) ) / 50.0);
        }

        if (rand.nextInt(0, 101) > move.getAccuracy()){
            System.out.println(atkMon.getName() + " missed!");
            type = 0;
        }
        return type;
    }
}
