import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Team> teams = new ArrayList<Team>();
        BattleManager battleManager = new BattleManager();

        boolean loopControl = true;
        Scanner scan = new Scanner(System.in);
        String input = "";
        TeamBuilder team = new TeamBuilder();
        teams = team.init();
        while (loopControl){
            System.out.println("{-< Pokemon Simulator >-}\n(1) Battle!\n(2) Team Builder\n(3) Exit");
            input = scan.next();
            switch (input.toLowerCase()){
                case "1":
                case "battle":
                    if( BattleManager.battleCheck(teams)){
                        battleManager.start(teams);
                    }
                    break;
                case "2":
                case "team":
                case "teams":
                case "team builder":
                    teams = team.start(teams);
                    break;
                case "3":
                case "exit":
                    team.saveTeams();
                    loopControl = false;
            }
        }

    }
}